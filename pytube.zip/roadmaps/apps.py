from django.apps import AppConfig

class RoadmapsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'roadmaps'
    verbose_name = 'Learning Roadmaps'